# Last Front: Dominion — Version 3.0 Visual Strike

## Visual overhaul
- Original vector-style hero portraits for Nova, Rex, Echo, Kira, Atlas and Shade.
- New mutant and boss artwork instead of emoji-only enemies.
- Reworked battlefield with road perspective, smoke, muzzle flashes, projectiles and impact effects.
- Hero cards, squad slots and recruit results now use the new character art.

## Gear / Forge presentation
- Custom weapon, armor, chip and boots visuals.
- R / SR / SSR / UR gear now has distinct visual rarity treatment.
- Forge reveal and fusion screens use the new gear presentation.

## Recruit presentation
- New animated transmission core.
- Reworked signal-pool cards and reveal animation.

## Save safety
- V3 uses `last_front_dominion_save_v3` and migrates V2/V1 saves when the Android signature is compatible.
- New manual Save Code export/import in Settings.

## Android update track
- Version code: 4
- Package ID stays: `com.growforge.lastfront`
- V3 includes a fixed prototype signing key for consistent sideloaded updates from V3 onward.
- This prototype signing setup is for personal testing, not Play Store release.
