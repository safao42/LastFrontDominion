#!/usr/bin/env bash
set -e
if ! command -v gradle >/dev/null; then
  echo "Gradle fehlt. Projekt in Android Studio öffnen oder Gradle 9.5 installieren."
  exit 1
fi
gradle assembleDebug
echo "Fertig: app/build/outputs/apk/debug/app-debug.apk"
