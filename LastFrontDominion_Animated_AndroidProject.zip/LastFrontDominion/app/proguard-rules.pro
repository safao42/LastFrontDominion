# No shrinking rules required for v1.
