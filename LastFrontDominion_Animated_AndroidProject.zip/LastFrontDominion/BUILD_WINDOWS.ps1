$ErrorActionPreference = "Stop"
Write-Host "Last Front: Dominion - APK Build" -ForegroundColor Cyan
if (-not $env:ANDROID_HOME -and -not $env:ANDROID_SDK_ROOT) {
  Write-Host "Kein Android SDK gefunden. Öffne das Projekt bitte einmal in Android Studio und installiere Android SDK Platform 36." -ForegroundColor Yellow
  exit 1
}
if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
  Write-Host "Gradle ist nicht im PATH. Am einfachsten: Projekt in Android Studio öffnen und Build > Build APK(s) wählen." -ForegroundColor Yellow
  exit 1
}
gradle assembleDebug
Write-Host "Fertig: app\build\outputs\apk\debug\app-debug.apk" -ForegroundColor Green
