# Last Front: Dominion – Version 2

Version 2 baut auf der Animated Edition auf und erweitert den Kern-Loop deutlich.

## Die vier V2-Schwerpunkte

### 1. Dominion-Schmiede
- Ausrüstung kann zerlegt werden
- Zerlegen gibt Schmiede-Teile und bei höherer Seltenheit Alloy-Cores
- Standard-, Advanced- und Elite-Rezepte
- neue Seltenheit **UR**
- Gear-Fusion: 3x R → SR, 3x SR → SSR, 3x SSR → UR
- Gear kann gesperrt werden, damit es nicht versehentlich zerlegt wird
- Gear-Level bis 15 und Upgrades kosten Gold + Teile
- vier Gear-Sets mit 2er-/4er-Boni

### 2. Squad-Synergien
- festes 3er-Squad statt rein automatischer Auswahl
- Fraktionen: Vanguard, Tech, Shadow
- Duo-/Trio-Fraktionsboni
- Balanced-Squad-Bonus für Tank + Support + Damage
- Gear-Set-Boni werden pro Held berechnet

### 3. Kampf 2.0
- Helden greifen sichtbar nacheinander an
- Rollen beeinflussen Crit und Skills
- automatische individuelle Hero-Skills
- Tank-Schild, Support-Heal, Sniper-/Rogue-/Mech-Spezialangriffe
- Boss Phase 2 / Enrage
- verbesserte Projektile, Skill-Effekte und Ultimate
- Radar beeinflusst Loot-Chance, Hangar beeinflusst Crit-Chance

### 4. Basis-Progression
- Gebäude werden abhängig vom HQ freigeschaltet
- Gebäude-Level sind durch das HQ begrenzt
- neue Dominion-Schmiede als eigenes Basisgebäude
- Barracks/Lab/MedBay/Hangar/Radar geben echte globale Boni
- HQ 5 schaltet Elite-Schmiede und UR-Progression frei

## Weitere Systeme
- Kampagne und Boss-Stages
- 6 Helden, Level, Sterne und Splitter
- Nahrung, Stahl, Gold, Diamanten, Energie
- Daily Rewards, Daily Missions, Achievements, Battle Pass
- Recruiting 1x / 10x
- lokaler Auto-Save, Sound und Vibration
- V1-Spielstände werden beim ersten V2-Start migriert
- Demo-Shop ohne Echtgeldzahlungen

## APK bauen
Das Projekt nutzt Android SDK 36 und Java 17. GitHub Actions kann mit `.github/workflows/build-apk.yml` eine Debug-APK erzeugen.

Package: `com.growforge.lastfront`  
VersionCode: `3`  
VersionName: `2.0.0-forge`
