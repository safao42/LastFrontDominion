# Last Front: Dominion – Animated Edition

Originales, Last-War-inspiriertes Mobile-Strategy-Spiel als Android-WebView-App.

## Neu in der Animated Edition
- animierte HQ/Base mit Drohnen, Energiebeam, Radar-Puls, Truppen und Ressourcen-Bubbles
- klickbare Gebäude mit eigenem Level-/Upgrade-System
- Nahrung, Stahl, Gold, Diamanten und Energie
- animierte Kämpfe mit Projektilen, Treffer-Effekten und Damage-Zahlen
- animierte Hero-Rekrutierung / Summon-Sequenz
- 6 Helden, Sterne, Splitter, Gear, Boss-Stages
- Daily Rewards, Quests, Achievements, Battle Pass, Demo-Shop
- lokaler Auto-Save, Sound und Vibration
- PWA-Dateien zusätzlich enthalten

## APK bauen
Projekt in Android Studio öffnen und `Build > Build APK(s)` wählen. Alternativ baut `.github/workflows/build-apk.yml` in GitHub Actions eine Debug-APK.

Technik: package `com.growforge.lastfront`, minSdk 26, compile/targetSdk 36, Version 2.0.0-animated. Echtgeldkäufe sind bewusst deaktiviert; Shop-Pakete verwenden nur In-Game-Diamanten.
