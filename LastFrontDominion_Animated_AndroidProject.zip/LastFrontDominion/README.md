# Last Front: Dominion V3 — Visual Strike

Original mobile strategy prototype for Android/WebView.

## V3 focus
V3 deliberately focuses on polish rather than adding lots of new menus. It replaces the prototype emoji character presentation with original vector-style hero and enemy art, upgrades the combat scene, improves gear visuals and gives recruiting a stronger reveal presentation.

Existing V2 systems remain: base/HQ progression, campaign combat, hero squad synergy, rage/ultimate, hero upgrades, recruit, daily missions, battle pass, gear sets, gear levels, salvage, crafting and R→SR→SSR→UR fusion.

## Save system
V3 stores locally under `last_front_dominion_save_v3` and can migrate V2/V1 browser saves when installed as a compatible update. Settings now also includes Save Code export/import for manual backups.

## Android
- Package: `com.growforge.lastfront`
- Version code: 4
- Version name: `3.0.0-visual-strike`
- Min SDK: 26
- Target/compile SDK: 36
- Java: 17

The included fixed prototype debug signing key is intended only for personal sideload testing, so V3+ builds can use one consistent signature. Do not use this signing setup for Play Store production.

## Build
The existing repository workflow can unzip this project and run:

`gradle assembleDebug`

Output:

`app/build/outputs/apk/debug/app-debug.apk`
