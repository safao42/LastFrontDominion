# V2 Changelog

- Added salvage materials: Parts + Alloy Cores
- Added UR gear rarity
- Added targeted Forge recipes and gear fusion
- Added gear locking and 4 gear sets
- Added manual 3-hero squad selection and faction synergy bonuses
- Added automatic individual hero skills during battles
- Added boss enrage / phase 2
- Added building unlock requirements and functional building bonuses
- Added Forge building to the animated HQ scene
- Added V1 save migration
